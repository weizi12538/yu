# WCLiquidArc — 微信液态弧形底栏插件

完整 Theos 工程，编译后得到 `WCLiquidArc.dylib`，用 lcsign 注入微信 IPA 即可。

---

## ⚠️ 先说清楚

**这台机器编不出成品 dylib**：没有 iOS SDK、没有 Mach-O 链接器（lld 装不上，无 root）、没有 Theos。
所以我交付的是**完整可编译源码**，你在自己的 Mac 上一条 `make` 出成品。

代码已做的静态检查：`{}` 全平衡、`@interface/@implementation` 与 `@end` 全部配对、已知 API 误用已修（`stringByDescribing` → `description`、`UIAlertActionDefault` → `UIAlertActionStyleDefault`）。但因为**无法真机编译**，仍可能有报错需要你补。

---

## 一、工程结构

```
liquidbar/
├── Makefile                                   编译配置（arm64 + arm64e，iOS 15+）
├── control                                    deb 元信息
├── layout/Library/MobileSubstrate/.../*.plist 注入目标（com.tencent.xin）
└── src/
    ├── LGEntry.m              入口：constructor、设置页注入、swizzle
    ├── LGCore.h/.m            配置持久化 + 悬浮窗口 + 主控
    ├── LGLiquidBar.h/.m       液态弧形底栏（核心 UI，536 行）
    ├── LGArcPath.h/.m         弧形几何计算
    ├── LGQuickPanel.h/.m      快捷面板（门轴 3D 展开）
    ├── LGAudioEngine.h/.m     音乐引擎（TM API + 网易云降级）
    └── LGSettingsController.h/.m  设置面板
```

总计 **2473 行**。

---

## 二、编译

```bash
# 1. 装 Theos（Mac 或 Linux）
export THEOS=~/theos
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"

# 2. 编译
cd liquidbar
make clean && make package FINALPACKAGE=1
```

产物：`.theos/obj/WCLiquidArc.dylib`（或 `packages/*.deb`）

**只要 dylib 的话**：
```bash
make
ls .theos/obj/debug/WCLiquidArc.dylib
```

---

## 三、lcsign 注入

1. 打开 lcsign，选「IPA 签名 / 注入」
2. 导入正版微信 IPA
3. 注入 `WCLiquidArc.dylib`
4. 签名安装到手机

非越狱设备注意：本插件**不依赖 CydiaSubstrate**，全部用 `objc/runtime` 的 `method_exchangeImplementations`，注入后即可运行。

---

## 四、功能对照你的需求

| 你的需求 | 实现位置 | 状态 |
|---|---|---|
| 液态弧形底栏 | `LGLiquidBar` + `LGArcPath` | ✅ 上排胶囊 + 两侧圆钮 + 下排内凹弧带 |
| 上排中间条左右滑动切换 | `didSwipeBand:` | ✅ 左滑上一首 / 右滑下一首 |
| 真实音乐播放器 | `LGAudioEngine`（AVPlayer） | ✅ 播放/暂停/切歌/进度/自动下一首 |
| 搜音乐 | `searchKeyword:source:` | ✅ TM 优先，缺失时走网易云公开接口 |
| TM API 接入 | `callTM:args:completion:` | ✅ 隐藏 WKWebView 桥，支持 Promise |
| 歌单载入 | `loadPlaylist:source:` | ✅ netease / qq |
| 设置面板 | `LGSettingsController` | ✅ 音乐/外观/按钮/快捷面板全部可调 |
| 微信 我-设置 里有入口 | `LGEntry.m` 的 `LGInjectEntry` | ⚠️ 见下方说明 |
| 中间条两侧按钮可配置 | `orbIcons` / `arcIcons` | ✅ 设置里逐个选 SF Symbol |
| 快捷面板门轴弹开 | `LGQuickPanel` | ✅ 左/右/底三种门轴，3D 旋转 + 透视 |
| 快捷面板显示微信入口 | `defaultQuickItems` | ✅ 扫一扫/收付款/朋友圈/收藏/搜一搜 |

### TM API 对接说明

你的插件内部通过隐藏 `WKWebView` 执行：

```js
window.__lgCall(rid, 'loadPlaylist', '["歌单ID","netease"]')
```

JS 侧：

```js
if (typeof TM === 'undefined') { post('cb', {rid:rid, err:'TM_NOT_FOUND'}); return; }
var r = TM[method].apply(TM, args);
if (r && typeof r.then === 'function') { r.then(...).catch(...); } else { post('cb', {rid:rid, data:r}); }
```

**注意**：这要求 `TM` 对象存在于同一个 WebView 上下文。如果 TM 是别的插件注入到主进程 JSContext 的，桥会拿不到 —— 此时自动降级到网易云公开搜索接口（`music.163.com/api/search/get/web` + `outer/url` 拼播放地址）。

要接稳 TM，需要你告诉我 **TM 是用哪种方式暴露的**（WebView 的 `window`？JSContext？还是 NSNotification），我按那条路改桥。

---

## 五、已知限制

| 项 | 说明 |
|---|---|
| 未真机编译 | 本机无 SDK，可能有编译报错需微调 |
| 设置页入口 | 用 `viewDidAppear` 探测类名含 `Setting` 的页面并加导航栏按钮。微信类名若变化需改 `LGLooksLikeSettingsVC` 的白名单。**更稳的方案**：底栏齿轮按钮已能直接打开设置，不依赖探测 |
| 快捷项 | 目前是微信 URL Scheme。要显示"已装插件列表"需要越狱环境的 tweak 目录扫描，非越狱不可行 |
| 弧形外观 | `topSag`/`bottomSag`/`thickness` 三个参数在设置里可调，默认值按你截图调的（10/14/58） |
| 歌词 | `LGSong.lrcString` 已留字段，UI 未做滚动歌词 |

---

## 六、调参速查

想更快贴近截图效果，直接改 `LGLiquidBar.m` 顶部常量：

```objc
static const CGFloat kTopRowH = 46.0;   // 上排高度
static const CGFloat kRowGap  = 8.0;    // 两排间距
static const CGFloat kOrbSize = 46.0;   // 圆钮直径
```

或改 `LGConfig` 默认值：

```objc
@"topSag": @10.0,      // 上边缘下凹
@"bottomSag": @14.0,   // 下边缘下凹
@"thickness": @58.0,   // 弧带厚度
```

---

## 七、下一步

要我继续的话，给我任一信息就能推进：

1. **TM 的暴露方式** → 把桥接稳
2. **编译报错贴给我** → 逐条修
3. **微信设置页类名**（用 `class-dump` 或运行时打印）→ 把入口做成原生插入行而非导航栏按钮
4. **截图微调**（比如弧度更弯、按钮更靠边）→ 我直接改常量
